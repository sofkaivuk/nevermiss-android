# NeverMiss — native Android alpha

**Version:** 0.1.0 (source-code alpha)  
**Goal:** Enter an important date once, get reminded every year, and restore dates on a replacement phone.

This is a genuine Kotlin/Jetpack Compose Android Studio source project, **not a compiled or field-tested APK**. The standalone calendar engine passes the included smoke checks; a complete Android build, Firebase integration and on-device reminders have **not** been executed in the authoring environment (no Android SDK/Gradle/network available here).

## What is implemented

- Add/edit birthdays, anniversaries, Slavas, holidays and custom yearly dates
- Upcoming dates, sorted by next occurrence; simple add/edit screen
- Fixed civil calendar, fixed Julian church calendar, and calculated Orthodox Easter
- Presets: Sveti Nikola, Sveti Jovan, Đurđevdan, Aranđelovdan, Sveta Petka, Sveti Luka, Orthodox Easter
- Non-leap-year February 29 policy: remind on February 28
- On-device SQLite/Room persistence, works offline
- Notification check around 9 AM for 7 days before, 1 day before, and on the day; test notification
- Rebuild/resume notification schedule after reboot, time/timezone changes, app update; periodic catch-up
- Optional Google Sign-In and per-user Firestore cloud sync (requires Firebase setup)
- Local dirty flag for durable upload retry; server-confirmed sync status
- User-specific events, local guest entries claimed on initial Google sign-in
- Soft-deletion with Trash and Restore
- JSON export/import as a separate, portable emergency escape hatch
- JUnit recurrence tests + a standalone command-line calendar smoke test

## Requirements

- Recent Android Studio, Android SDK platform 36, Android 8.0+ device/emulator
- JDK 17+ and Gradle 8.13 (AGP 8.13.2)
- Network on the development machine to download Android/Gradle/Firebase dependencies
- Optional: Firebase project, Google auth, Cloud Firestore, SHA-1 fingerprint

## Quick start

1. Unzip **NeverMiss-Android.zip**.
2. Open the `NeverMiss-Android` directory as a project in Android Studio.
3. If asked about Gradle configuration, use **Gradle 8.13**. This ZIP does not contain a prebuilt Gradle wrapper JAR; if Android Studio cannot configure Gradle automatically, install Gradle once, run `gradle wrapper --gradle-version 8.13`, then reopen the project using the generated wrapper.
4. Install Android SDK 36 in SDK Manager and let Gradle sync/download dependencies.
5. Run the `app` module on an Android 8+ emulator/device.
6. Without Firebase, local dates and reminders can be tested, but **dates are NOT backed up to the cloud**. Set up Firebase before trusting it with important dates: see [SETUP.md](SETUP.md).
7. On Android 13+, allow notification permission, open **Safety → Send test**, then create a test date.

### Optional source-only calendar check

With a local Kotlin compiler, run `tools/run-calendar-smoke.sh` (no Android SDK needed). Unit tests are in `app/src/test/.../DateRulesTest.kt` (`gradle testDebugUnitTest`).

## Simplified architecture

```text
Compose screens → MainViewModel
                       ├── Room/SQLite (events + delivery ledger + dirty uploads)
                       ├── WorkManager ReminderCheckWorker
                       │      └── AlarmManager daily around 09:00 → notifications
                       ├── Firestore sync worker (when configured & signed in)
                       └── Storage Access Framework → JSON import/export

Firebase Auth / Google account → users/{uid}/events/{eventId}
```

## How to prove a phone replacement

1. Configure Firebase, sign in to Google, create at least five events.
2. Open **Safety** and press **Sync now**; wait for **Cloud synced**, with no pending changes.
3. On a second (or freshly reset test) Android phone, install the same app, enable notifications, and sign in with the **same Google account**.
4. Verify all five events appear and their next dates match.
5. Send a test notification, then also check an actual scheduled reminder.
6. Export a JSON backup and store it somewhere outside the phone.

**Never rely on a status that only says “Saved on this phone”.** Cloud sync must explicitly confirm success first.

## Known alpha limitations (not production ready)

- **No APK supplied**; device/Gradle build and end-to-end Firebase test are still required.
- Reminders use an **inexact daily alarm** with WorkManager catch-up. Android may delay alerts; phone-off, disabled notifications, force-stop, and restrictive battery modes prevent guarantees. We deliberately do not request restricted exact-alarm permissions in alpha.
- Reminder schedule (7/1/0 days, around 09:00 **device-local time**) is fixed; no per-event times or permanent home timezone yet.
- Manual custom dates repeat annually; one-off dates, per-event reminder choices, birthday age and iCalendar export are not yet implemented.
- Supported presets must be verified against the family's actual observance practice before product release.
- Conflict handling is simple: unsynced local edits take precedence; otherwise newer client timestamps win. **Clock skew and truly concurrent offline edits require a conflict-safe protocol before public release.**
- Cloud sync requires the owner to configure Firebase and Google authentication. Firestore's cloud copy **is not a history of independent backups**. Scheduled server backups and a restore drill should be added before critical use.
- Trash items are retained; automatic 90-day purge is not yet implemented.
- JSON import skips existing IDs in the same account to avoid overwriting data. It is not a full database rollback.
- The UI is currently English with Serbian-language Slava names; bilingual UI is still to do.
- No telemetry, operational monitoring, Firebase emulator rules tests, accessibility audit, integration tests or Play Store release configuration yet.
- `android:allowBackup=false` deliberately avoids relying on Android's opaque auto-backup. **Cloud sync or your exported JSON file is required for recovery.**

## Security

Firestore rules in `firebase/firestore.rules` restrict reads and writes to each signed-in user's path. These rules must be deployed before cloud testing. Avoid putting your real personal occasion data into a public Firestore database.

## Source map

- `DateRules.kt` — Gregorian, Julian and Orthodox Paschal calendar math
- `LocalStore.kt` — Room tables and queries
- `CloudSync.kt` — Google account scoping and Firestore sync/retry
- `ReminderJobs.kt` — daily AlarmManager scheduling, WorkManager catch-up and notification ledger
- `MainViewModel.kt` — UI commands, Google Credential Manager sign-in and JSON recovery
- `MainActivity.kt` — simple Compose home, editor, Safety and Trash
- `BackupCodec.kt` — portable JSON validation/export

## Next engineering gates

**Gate A:** Complete Android build with instrumentation/emulator smoke test.  
**Gate B:** Firebase user-isolation test, network-off → network-on retry, simultaneous edits, and second-device restore.  
**Gate C:** Two weeks of actual reminder delivery testing, including restarts, Doze, battery optimization, daylight-saving and time-zone changes.  
**Gate D:** Independent backup snapshots, schema migrations, accessibility/localization and beta signing.
