import com.nevermiss.app.DateRules
import java.time.LocalDate

fun main() {
    check(DateRules.fromJulian(2026, 12, 6) == LocalDate.of(2026, 12, 19))
    check(DateRules.fromJulian(2100, 12, 6) == LocalDate.of(2100, 12, 20))
    check(DateRules.orthodoxEaster(2026) == LocalDate.of(2026, 4, 12))
    check(DateRules.orthodoxEaster(2027) == LocalDate.of(2027, 5, 2))
    check(DateRules.dueToday(DateRules.CIVIL, 1, 1, 0, 7, LocalDate.of(2026, 12, 25)))
    check(DateRules.occurrence(2027, DateRules.CIVIL, 2, 29) == LocalDate.of(2027, 2, 28))
    println("PASS: Julian dates, 2100 shift, Pascha, leap-day and cross-year reminders")
}
