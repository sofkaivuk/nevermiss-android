#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc app/src/main/java/com/nevermiss/app/DateRules.kt tools/CalendarSmoke.kt \
  -include-runtime -d "$TMP/calendar-tests.jar"
java -jar "$TMP/calendar-tests.jar"
