# Firebase and build setup for NeverMiss

NeverMiss works as a **local-only reminder app** immediately after Android Studio can build it. Cloud migration will not work until you connect your own Firebase project.

## A. Build the local app

1. Install Android Studio and SDK Platform API 36.
2. File → Open → select the unzipped `NeverMiss-Android` directory.
3. Gradle sync requires Gradle 8.13, JDK 17+, and an internet connection to retrieve dependencies.
4. This source archive does not include Gradle's binary wrapper. If necessary, run `gradle wrapper --gradle-version 8.13` once with an installed Gradle distribution. Then build with `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
5. Run the Android app on a device/emulator. The app will display a clear **Not backed up** warning.

## B. Add cloud synchronization

1. Create a project at https://console.firebase.google.com/.
2. Add an **Android app** with package name `com.nevermiss.app` (or update the project's `applicationId` consistently before registration).
3. Add your debug signing certificate SHA-1 (Android Studio Gradle `signingReport` task); for production, also register the release-key fingerprint. Add SHA-256 too if prompted.
4. Firebase Authentication → Sign-in method → enable **Google**.
5. Firebase console → Project settings → download the **updated** `google-services.json` file and place it at `app/google-services.json`.
6. Firestore Database → create the database in an appropriate region. Start with production/security rules, not permanently permissive test rules.
7. Deploy the contents of `firebase/firestore.rules` to Firestore Rules. The app assumes `users/{uid}/events/{eventId}` and denies cross-user access.
8. Re-sync Gradle and rebuild. **Continue with Google** now uses Credential Manager and Firebase Auth.
9. Sign in, add a date, and verify Firestore contains a document under your own user ID. Open Safety to check the last confirmed sync.
10. Install the same APK on another test device, sign in with the same Google account, and verify recovery.

**Important:** Do not commit `google-services.json` or signing keys to a public repository. Google client IDs are not passwords, but keep environment-specific config out of source control and apply real Firestore rules.

## C. Production-safety requirements (not included in alpha)

- Enable scheduled Firestore backups with an appropriate retention policy and verify an actual restore in a *separate* database. This may require the Firebase Blaze billing plan.
- Test security rules with the Firebase Emulator Suite: user A can access A's entries and **cannot** access B's entries.
- Add conflict-safe revision tracking (e.g., server-side generations / conflict records) instead of device-clock last-write-wins.
- Implement database migrations, backup snapshot recovery, monitoring and actual device notification tests.
- Decide whether you need exact alarms and whether the chosen Play policy permits the relevant permission. Alpha deliberately uses inexact alarms.
- Review notifications on Android 13+, Android 14+, Doze, force-stop, and manufacturer-specific restrictions.

## D. What to test before depending on it

- Airplane mode → add two dates → reconnect → confirm all cloud uploads.
- Reinstall/new device → Google sign-in → all dates restored.
- Sign out, sign in with a *different* Google account → no previous account's dates appear.
- Delete a date → restore it from Trash; confirm sync on another device.
- Set a test date for today and the 7-day or 1-day notification windows.
- Reboot and alter timezone. Check that the next daily reminder still arrives.
- Export JSON to a separate storage provider; import into an empty account and verify records.

## Useful documentation

- Android notification runtime permission: https://developer.android.com/develop/ui/views/notifications/notification-permission
- Android alarms: https://developer.android.com/develop/background-work/services/alarms
- Firebase Google auth + Credential Manager: https://firebase.google.com/docs/auth/android/google-signin
- Firebase Android setup: https://firebase.google.com/docs/android/setup
- Firestore security rules: https://firebase.google.com/docs/firestore/security/get-started
- WorkManager: https://developer.android.com/topic/libraries/architecture/workmanager
