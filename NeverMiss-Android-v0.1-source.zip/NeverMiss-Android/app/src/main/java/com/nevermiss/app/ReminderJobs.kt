package com.nevermiss.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object ReminderJobs {
    private const val CHANNEL_ID = "nevermiss_dates"
    private const val ALARM_REQUEST = 92832

    fun createNotificationChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(
            CHANNEL_ID, "Important dates", NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Birthdays, anniversaries, Slavas and other dates" })
    }

    fun notificationsAllowed(context: Context): Boolean =
        (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(
            context, Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED) &&
            NotificationManagerCompat.from(context).areNotificationsEnabled()

    fun scheduleDaily(context: Context) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, ReminderAlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, ALARM_REQUEST, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        // Intentionally inexact: we do not request restricted exact-alarm permissions.
        val next = DateRules.nextAlarm(ZonedDateTime.now()).toInstant().toEpochMilli()
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pending)
    }

    fun queueMaintenance(context: Context) {
        WorkManager.getInstance(context).enqueueUniqueWork(
            "reminder-check", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<ReminderCheckWorker>().build()
        )
    }

    fun schedulePeriodicMaintenance(context: Context) {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "reminder-periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ReminderCheckWorker>(12, TimeUnit.HOURS).build()
        )
    }

    fun sendTestNotification(context: Context): Boolean {
        if (!notificationsAllowed(context)) return false
        post(context, "nevermiss-test", "NeverMiss test",
            "Notifications are enabled on this phone.")
        return true
    }

    fun post(context: Context, id: String, title: String, message: String) {
        val openApp = PendingIntent.getActivity(context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(Notification.BigTextStyle().bigText(message))
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .setCategory(Notification.CATEGORY_REMINDER)
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify(id.hashCode(), notification)
    }
}

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        ReminderJobs.scheduleDaily(context)
        ReminderJobs.queueMaintenance(context)
    }
}

class SystemChangeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        ReminderJobs.scheduleDaily(context)
        ReminderJobs.queueMaintenance(context)
    }
}

class ReminderCheckWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as NeverMissApplication
        ReminderJobs.scheduleDaily(app)
        if (!ReminderJobs.notificationsAllowed(app)) return Result.success()
        // On reboot / app open, catch up if today's 9:00 alarm was missed.
        if (LocalTime.now().isBefore(LocalTime.of(9, 0))) return Result.success()
        val today = LocalDate.now()
        val events = app.signedInUid()?.let { app.dao.activeOwned(it) }
            ?: app.dao.activeGuests()
        for (event in events) {
            for (days in DateRules.supportedReminders) {
                if (!DateRules.dueToday(event.rule, event.month, event.day,
                        event.paschaOffset, days, today)) continue
                val ledgerId = "${event.id}:$today:$days"
                if (app.dao.wasPosted(ledgerId)) continue
                val message = when (days) {
                    0 -> "Today is ${event.title}!"
                    1 -> "Tomorrow is ${event.title}."
                    else -> "${event.title} is in $days days."
                }
                try {
                    ReminderJobs.post(app, ledgerId, "NeverMiss", message)
                    app.dao.markPosted(DeliveryRecord(ledgerId))
                } catch (_: SecurityException) {
                    // Do not log delivery; try again after permissions are granted.
                    return Result.success()
                }
            }
        }
        return Result.success()
    }
}
