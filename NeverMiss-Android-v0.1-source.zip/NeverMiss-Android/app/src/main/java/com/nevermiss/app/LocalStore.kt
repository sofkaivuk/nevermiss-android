package com.nevermiss.app

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import java.util.UUID

@Entity(tableName = "occasions")
data class Occasion(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val ownerUid: String? = null,  // null = local-only guest entry
    val title: String,
    val category: String = "OTHER",
    val rule: String = DateRules.CIVIL,
    val month: Int,
    val day: Int,
    val paschaOffset: Int = 0,
    val note: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val deletedAt: Long? = null,
    val dirty: Boolean = true    // durable, offline upload queue
)

@Entity(tableName = "delivery_ledger")
data class DeliveryRecord(
    @PrimaryKey val id: String,  // event-id:date:offset
    val postedAt: Long = System.currentTimeMillis()
)

@Dao
interface OccasionDao {
    @Query("SELECT * FROM occasions WHERE ownerUid IS NULL AND deletedAt IS NULL")
    fun observeGuests(): Flow<List<Occasion>>

    @Query("SELECT * FROM occasions WHERE ownerUid = :uid AND deletedAt IS NULL")
    fun observeOwned(uid: String): Flow<List<Occasion>>

    @Query("SELECT * FROM occasions WHERE ownerUid IS NULL AND deletedAt IS NOT NULL")
    fun observeGuestTrash(): Flow<List<Occasion>>

    @Query("SELECT * FROM occasions WHERE ownerUid = :uid AND deletedAt IS NOT NULL")
    fun observeOwnedTrash(uid: String): Flow<List<Occasion>>

    @Query("SELECT * FROM occasions WHERE ownerUid IS NULL")
    suspend fun guestEntries(): List<Occasion>

    @Query("SELECT * FROM occasions WHERE ownerUid = :uid")
    suspend fun ownedEntries(uid: String): List<Occasion>

    @Query("SELECT * FROM occasions")
    suspend fun allEntries(): List<Occasion>

    @Query("SELECT * FROM occasions WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): Occasion?

    @Query("SELECT * FROM occasions WHERE ownerUid = :uid AND deletedAt IS NULL")
    suspend fun activeOwned(uid: String): List<Occasion>

    @Query("SELECT * FROM occasions WHERE ownerUid IS NULL AND deletedAt IS NULL")
    suspend fun activeGuests(): List<Occasion>

    @Query("SELECT COUNT(*) FROM occasions WHERE ownerUid = :uid AND dirty = 1")
    suspend fun pendingCount(uid: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: Occasion)

    @Query("UPDATE occasions SET ownerUid = :uid, dirty = 1 WHERE ownerUid IS NULL")
    suspend fun claimGuests(uid: String)

    @Query("UPDATE occasions SET dirty = 0 WHERE id = :id AND updatedAt = :revision")
    suspend fun markClean(id: String, revision: Long)

    @Query("SELECT EXISTS(SELECT 1 FROM delivery_ledger WHERE id = :id)")
    suspend fun wasPosted(id: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun markPosted(record: DeliveryRecord)
}

@Database(entities = [Occasion::class, DeliveryRecord::class], version = 1, exportSchema = false)
abstract class NeverMissDatabase : RoomDatabase() {
    abstract fun occasionDao(): OccasionDao
}
