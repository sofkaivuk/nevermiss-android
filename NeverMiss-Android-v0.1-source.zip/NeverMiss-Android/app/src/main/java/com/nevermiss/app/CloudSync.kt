package com.nevermiss.app

import android.app.Application
import androidx.room.Room
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Source
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class NeverMissApplication : Application() {
    val database: NeverMissDatabase by lazy {
        Room.databaseBuilder(this, NeverMissDatabase::class.java, "nevermiss.db").build()
    }
    val dao: OccasionDao get() = database.occasionDao()
    val cloud: CloudSync by lazy { CloudSync(this) }

    val firebaseReady: Boolean get() = FirebaseApp.getApps(this).isNotEmpty()
    fun signedInUid(): String? = if (firebaseReady) FirebaseAuth.getInstance().currentUser?.uid else null

    override fun onCreate() {
        super.onCreate()
        ReminderJobs.createNotificationChannel(this)
        ReminderJobs.queueMaintenance(this)
        ReminderJobs.scheduleDaily(this)
        ReminderJobs.schedulePeriodicMaintenance(this)
        schedulePeriodicCloudSync()
    }

    fun queueCloudSync() {
        if (!firebaseReady || signedInUid() == null) return
        val request = OneTimeWorkRequestBuilder<CloudSyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(this).enqueueUniqueWork("cloud-sync", ExistingWorkPolicy.KEEP, request)
    }

    private fun schedulePeriodicCloudSync() {
        val request = PeriodicWorkRequestBuilder<CloudSyncWorker>(12, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "cloud-periodic", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}

data class CloudState(
    val description: String = "Not backed up — connect Google",
    val pending: Int = 0,
    val lastSynced: Long? = null,
    val error: String? = null
)

class CloudSync(private val app: NeverMissApplication) {
    private val mutex = Mutex()
    private var registration: ListenerRegistration? = null
    private val mutableState = MutableStateFlow(CloudState())
    val state: StateFlow<CloudState> = mutableState

    private fun collection(uid: String) = FirebaseFirestore.getInstance()
        .collection("users").document(uid).collection("events")

    fun markLocalPending() {
        if (app.signedInUid() != null) {
            mutableState.value = mutableState.value.copy(
                description = "Saved locally — upload pending",
                pending = maxOf(1, mutableState.value.pending)
            )
        }
    }

    fun watchAccount(uid: String?) {
        registration?.remove()
        registration = null
        if (!app.firebaseReady) {
            mutableState.value = CloudState("Cloud needs Firebase setup")
            return
        }
        if (uid == null) {
            mutableState.value = CloudState("Not backed up — sign in with Google")
            return
        }
        mutableState.value = CloudState("Connecting to cloud…", lastSynced = lastSynced(uid))
        registration = collection(uid).addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
            if (app.signedInUid() != uid) return@addSnapshotListener
            if (error != null) {
                mutableState.value = mutableState.value.copy(
                    description = "Cloud unavailable — will retry", error = error.localizedMessage
                )
            } else if (snapshot != null && !snapshot.metadata.isFromCache &&
                !snapshot.metadata.hasPendingWrites()) {
                // Download new/modified items from other devices without trusting the cache as a backup.
                app.queueCloudSync()
            }
        }
    }

    suspend fun syncOnce(uid: String) = mutex.withLock {
        if (!app.firebaseReady || app.signedInUid() != uid) return@withLock
        try {
            val dao = app.dao
            val pending = dao.pendingCount(uid)
            mutableState.value = CloudState("Synchronizing…", pending, lastSynced(uid))

            // Server-only read prevents falsely claiming a cache-only restore as confirmed.
            val documents = collection(uid).get(Source.SERVER).await().documents
            val cloud = documents.mapNotNull { document ->
                try { fromCloud(uid, document.id, document.data ?: emptyMap()) }
                catch (_: Exception) { null }
            }.associateBy { it.id }

            val local = dao.ownedEntries(uid).associateBy { it.id }
            cloud.values.forEach { remote ->
                val onPhone = local[remote.id]
                if (onPhone == null || (!onPhone.dirty && remote.updatedAt > onPhone.updatedAt)) {
                    dao.upsert(remote.copy(dirty = false))
                }
            }

            val merged = dao.ownedEntries(uid)
            merged.forEach { entry ->
                val remote = cloud[entry.id]
                if (entry.dirty || remote == null || entry.updatedAt > remote.updatedAt) {
                    // Firestore acknowledges this Task only when the write reaches the backend.
                    collection(uid).document(entry.id).set(toCloud(entry)).await()
                    dao.markClean(entry.id, entry.updatedAt)
                }
            }
            val stillPending = dao.pendingCount(uid)
            val syncedAt = System.currentTimeMillis()
            if (stillPending == 0) {
                app.getSharedPreferences("nevermiss-sync", 0).edit()
                    .putLong("last-$uid", syncedAt).apply()
            }
            mutableState.value = CloudState(
                description = if (stillPending == 0) "Cloud synced" else "Changes pending upload",
                pending = stillPending,
                lastSynced = if (stillPending == 0) syncedAt else lastSynced(uid)
            )
            ReminderJobs.queueMaintenance(app) // new-phone restore: schedule downloaded occasions
        } catch (e: Exception) {
            val pending = app.dao.pendingCount(uid)
            mutableState.value = CloudState(
                "Cloud offline — changes saved on this phone", pending, lastSynced(uid),
                e.localizedMessage
            )
            throw e
        }
    }

    private fun lastSynced(uid: String): Long? = app.getSharedPreferences("nevermiss-sync", 0)
        .getLong("last-$uid", 0L).takeIf { it > 0L }

    private fun toCloud(e: Occasion): Map<String, Any?> = mapOf(
        "title" to e.title, "category" to e.category, "rule" to e.rule,
        "month" to e.month, "day" to e.day, "paschaOffset" to e.paschaOffset,
        "note" to e.note, "updatedAt" to e.updatedAt, "deletedAt" to e.deletedAt
    )

    private fun fromCloud(uid: String, id: String, map: Map<String, Any?>): Occasion? {
        val title = (map["title"] as? String)?.trim().orEmpty()
        if (title.isBlank()) return null
        val rule = map["rule"] as? String ?: DateRules.CIVIL
        if (rule !in listOf(DateRules.CIVIL, DateRules.JULIAN, DateRules.PASCHA)) return null
        val month = (map["month"] as? Number)?.toInt() ?: return null
        val day = (map["day"] as? Number)?.toInt() ?: return null
        val offset = (map["paschaOffset"] as? Number)?.toInt() ?: 0
        if (month !in 1..12 || day !in 1..31 || offset !in -365..365) return null
        DateRules.occurrence(2028, rule, month, day, offset) // reject invalid remote dates
        return Occasion(id = id, ownerUid = uid, title = title,
            category = (map["category"] as? String) ?: "OTHER",
            rule = rule, month = month, day = day, paschaOffset = offset,
            note = (map["note"] as? String) ?: "",
            updatedAt = (map["updatedAt"] as? Number)?.toLong() ?: 0L,
            deletedAt = (map["deletedAt"] as? Number)?.toLong(), dirty = false)
    }
}

class CloudSyncWorker(context: android.content.Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as NeverMissApplication
        val uid = app.signedInUid() ?: return Result.success()
        return try {
            app.cloud.syncOnce(uid)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
