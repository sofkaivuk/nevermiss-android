package com.nevermiss.app

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/** Portable backup without Firebase or account identifiers. */
object BackupCodec {
    fun encode(events: List<Occasion>): String {
        val data = JSONArray()
        events.filter { it.deletedAt == null }.forEach { event ->
            data.put(JSONObject().apply {
                put("id", event.id)
                put("title", event.title)
                put("category", event.category)
                put("rule", event.rule)
                put("month", event.month)
                put("day", event.day)
                put("paschaOffset", event.paschaOffset)
                put("note", event.note)
            })
        }
        return JSONObject().put("format", "nevermiss-backup")
            .put("version", 1)
            .put("events", data)
            .toString(2)
    }

    fun decode(json: String): List<Occasion> {
        require(json.length <= 5_000_000) { "The backup file is too large" }
        val root = JSONObject(json)
        require(root.optString("format") == "nevermiss-backup") { "Not a NeverMiss backup" }
        require(root.optInt("version") == 1) { "Unsupported backup version" }
        val array = root.getJSONArray("events")
        require(array.length() <= 10_000) { "Too many events" }
        return (0 until array.length()).map { idx ->
            val item = array.getJSONObject(idx)
            val title = item.getString("title").trim()
            require(title.isNotBlank() && title.length <= 120) { "Invalid event title" }
            val rule = item.getString("rule")
            require(rule in listOf(DateRules.CIVIL, DateRules.JULIAN, DateRules.PASCHA))
            val month = item.getInt("month")
            val day = item.getInt("day")
            val offset = item.optInt("paschaOffset", 0)
            require(offset in -365..365)
            require(month in 1..12 && day in 1..31)
            // Validate calendar fields before writing anything to Room.
            DateRules.occurrence(2028, rule, month, day, offset)
            val id = item.getString("id")
            require(id.matches(Regex("[a-fA-F0-9-]{36}"))) { "Invalid event ID" }
            val category = item.optString("category", "OTHER")
            require(category in listOf("BIRTHDAY", "ANNIVERSARY", "SLAVA", "HOLIDAY", "OTHER"))
            val note = item.optString("note", "")
            require(note.length <= 2000)
            Occasion(id = id, title = title, category = category, rule = rule,
                month = month, day = day, paschaOffset = offset, note = note)
        }
    }
}
