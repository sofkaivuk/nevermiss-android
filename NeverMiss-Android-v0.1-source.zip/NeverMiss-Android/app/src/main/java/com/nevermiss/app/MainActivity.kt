package com.nevermiss.app

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.rememberScrollState
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                NeverMissScreen()
            }
        }
    }
}

private val dateFormat = DateTimeFormatter.ofPattern("d MMM yyyy")
private val categories = listOf("BIRTHDAY", "ANNIVERSARY", "SLAVA", "HOLIDAY", "OTHER")

private fun nextDate(event: Occasion, today: LocalDate = LocalDate.now()): LocalDate =
    DateRules.nextOccurrence(event.rule, event.month, event.day, event.paschaOffset, today)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NeverMissScreen(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val activity = context as Activity
    val app = context.applicationContext as NeverMissApplication
    val lifecycle = LocalLifecycleOwner.current
    val events by vm.occasions.collectAsStateWithLifecycle()
    val trashed by vm.trash.collectAsStateWithLifecycle()
    val uid by vm.accountUid.collectAsStateWithLifecycle()
    val email by vm.accountEmail.collectAsStateWithLifecycle()
    val cloud by vm.cloudState.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val snackbars = remember { SnackbarHostState() }
    var editorEvent by remember { mutableStateOf<Occasion?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var showSafety by remember { mutableStateOf(false) }
    var showTrash by remember { mutableStateOf(false) }
    var notificationsEnabled by remember { mutableStateOf(ReminderJobs.notificationsAllowed(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationsEnabled = ReminderJobs.notificationsAllowed(context)
        ReminderJobs.queueMaintenance(context)
        if (!granted) vm.report("Notifications are disabled. Reminders cannot appear.")
    }
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri -> uri?.let(vm::exportTo) }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(vm::importFrom) }

    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                notificationsEnabled = ReminderJobs.notificationsAllowed(context)
                ReminderJobs.queueMaintenance(context)
                app.queueCloudSync()
            }
        }
        lifecycle.lifecycle.addObserver(observer)
        onDispose { lifecycle.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(message) {
        message?.let {
            snackbars.showSnackbar(it)
            vm.clearMessage()
        }
    }
    LaunchedEffect(uid) {
        showEditor = false
        editorEvent = null
    }

    val today = LocalDate.now()
    val upcoming = remember(events, today) {
        events.map { it to nextDate(it, today) }.sortedBy { it.second }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("NeverMiss", fontWeight = FontWeight.Bold) },
                actions = {
                    TextButton(onClick = { showSafety = !showSafety }) {
                        Text(if (showSafety) "Dates" else "Safety")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbars) },
        floatingActionButton = {
            if (!showSafety) FloatingActionButton(onClick = {
                editorEvent = null
                showEditor = true
            }) { Text("+", style = MaterialTheme.typography.headlineMedium) }
        }
    ) { padding ->
        if (showSafety) {
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Data & reminders", style = MaterialTheme.typography.headlineSmall)
                AccountCard(vm, uid, email, cloud.description,
                    cloud.lastSynced?.let { java.time.Instant.ofEpochMilli(it)
                        .atZone(java.time.ZoneId.systemDefault()).format(
                            DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm")) })
                if (cloud.pending > 0) Text("${cloud.pending} pending changes",
                    color = MaterialTheme.colorScheme.error)
                NotificationCard(notificationsEnabled,
                    onEnable = {
                        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                        })
                    },
                    onTest = {
                        if (ReminderJobs.sendTestNotification(context)) vm.report("Test sent")
                        else vm.report("Enable notifications first")
                    }
                )
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Portable backup", style = MaterialTheme.typography.titleMedium)
                        Text("Export a JSON copy you can store independently of this phone. Import adds missing dates without overwriting existing ones.")
                        OutlinedButton(onClick = { exportLauncher.launch("NeverMiss-backup.json") }) {
                            Text("Export dates")
                        }
                        OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain")) }) {
                            Text("Import backup")
                        }
                    }
                }
                OutlinedButton(onClick = { showTrash = true }) {
                    Text("Trash (${trashed.size}) — restore deleted dates")
                }
                Text("Reminders run on this device around 9:00 AM local time. Android may delay notifications. The cloud is a sync copy, not a separate historical backup.",
                    style = MaterialTheme.typography.bodySmall)
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Your next important dates", style = MaterialTheme.typography.headlineSmall)
                }
                item {
                    if (uid == null) {
                        Card {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Not backed up", fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error)
                                Text("Dates are only on this phone until you connect Google and finish syncing.")
                                Button(onClick = { vm.signIn(activity) }, enabled = vm.firebaseConfigured) {
                                    Text("Connect Google account")
                                }
                                if (!vm.firebaseConfigured) Text("Cloud setup required: see SETUP.md",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    } else {
                        Card {
                            Column(Modifier.padding(16.dp)) {
                                Text(cloud.description, fontWeight = FontWeight.SemiBold)
                                Text(if (cloud.pending == 0) "Account: ${email ?: "Connected"}"
                                    else "${cloud.pending} changes not yet confirmed by cloud",
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                if (!notificationsEnabled) {
                    item {
                        Card {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Reminders are OFF", fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error)
                                Text("Allow notifications so the phone can remind you.")
                                Button(onClick = {
                                    if (Build.VERSION.SDK_INT >= 33)
                                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    else context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                                        putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                    })
                                }) { Text("Enable reminders") }
                            }
                        }
                    }
                }
                if (upcoming.isNotEmpty()) {
                    item {
                        val first = upcoming.first()
                        val days = ChronoUnit.DAYS.between(today, first.second)
                        Card {
                            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("NEXT OCCASION", style = MaterialTheme.typography.labelMedium)
                                Text(first.first.title, style = MaterialTheme.typography.headlineMedium)
                                Text(first.second.format(dateFormat))
                                Text(if (days == 0L) "Today!" else "In $days days",
                                    fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                    item { Text("All upcoming", style = MaterialTheme.typography.titleLarge) }
                    items(upcoming, key = { it.first.id }) { (event, date) ->
                        OccasionRow(event, date, today) {
                            editorEvent = event
                            showEditor = true
                        }
                    }
                } else {
                    item {
                        Card {
                            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("No dates yet", style = MaterialTheme.typography.titleLarge)
                                Text("Tap + to add a birthday, anniversary, Slava, or other important day.")
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(64.dp)) }
            }
        }
    }

    if (showEditor) OccasionEditor(
        original = editorEvent,
        onDismiss = { showEditor = false },
        onSave = { draft ->
            vm.save(editorEvent, draft.title, draft.category, draft.rule,
                draft.month, draft.day, draft.offset, draft.note)
            showEditor = false
        },
        onDelete = { event ->
            vm.trashEvent(event)
            showEditor = false
        }
    )
    if (showTrash) AlertDialog(
        onDismissRequest = { showTrash = false },
        title = { Text("Trash") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (trashed.isEmpty()) Text("Trash is empty")
                trashed.forEach { e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(e.title, Modifier.weight(1f))
                        TextButton(onClick = { vm.restoreEvent(e) }) { Text("Restore") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { showTrash = false }) { Text("Close") } }
    )
}

@Composable
private fun AccountCard(vm: MainViewModel, uid: String?, email: String?, status: String,
                        lastSync: String?) {
    val activity = LocalContext.current as Activity
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Google account", style = MaterialTheme.typography.titleMedium)
            Text(email ?: "Not connected")
            Text(status, style = MaterialTheme.typography.bodyMedium)
            if (lastSync != null) Text("Last confirmed sync: $lastSync",
                style = MaterialTheme.typography.bodySmall)
            if (uid == null) {
                Button(enabled = vm.firebaseConfigured, onClick = { vm.signIn(activity) }) {
                    Text("Continue with Google")
                }
                if (!vm.firebaseConfigured) Text("Firebase setup missing; see SETUP.md")
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = vm::retrySync) { Text("Sync now") }
                    TextButton(onClick = { vm.signOut(activity) }) { Text("Sign out") }
                }
            }
        }
    }
}

@Composable
private fun NotificationCard(enabled: Boolean, onEnable: () -> Unit, onTest: () -> Unit) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Notification health", style = MaterialTheme.typography.titleMedium)
            Text(if (enabled) "Notifications enabled" else "Notifications disabled — action required")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!enabled) Button(onClick = onEnable) { Text("Enable") }
                OutlinedButton(onClick = onTest) { Text("Send test") }
            }
        }
    }
}

@Composable
private fun OccasionRow(event: Occasion, next: LocalDate, today: LocalDate, onClick: () -> Unit) {
    val days = ChronoUnit.DAYS.between(today, next)
    Card(onClick = onClick) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${next.dayOfMonth}", style = MaterialTheme.typography.headlineSmall)
                Text(next.month.name.take(3), style = MaterialTheme.typography.labelSmall)
            }
            Column(Modifier.weight(1f)) {
                Text(event.title, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(event.category.lowercase().replaceFirstChar { it.uppercase() },
                    style = MaterialTheme.typography.bodySmall)
            }
            Text(if (days == 0L) "Today" else "$days d",
                style = MaterialTheme.typography.labelLarge)
        }
    }
}

private data class Draft(
    val title: String, val category: String, val rule: String,
    val month: Int, val day: Int, val offset: Int, val note: String
)

private data class Preset(val name: String, val rule: String, val month: Int, val day: Int,
                          val offset: Int = 0)

private val slavaPresets = listOf(
    Preset("Sveti Nikola", DateRules.JULIAN, 12, 6),
    Preset("Sveti Jovan", DateRules.JULIAN, 1, 7),
    Preset("Đurđevdan", DateRules.JULIAN, 4, 23),
    Preset("Aranđelovdan", DateRules.JULIAN, 11, 8),
    Preset("Sveta Petka", DateRules.JULIAN, 10, 14),
    Preset("Sveti Luka", DateRules.JULIAN, 10, 18)
)

@Composable
private fun OccasionEditor(original: Occasion?, onDismiss: () -> Unit,
                            onSave: (Draft) -> Unit, onDelete: (Occasion) -> Unit) {
    val context = LocalContext.current
    val current = LocalDate.now()
    var title by remember(original?.id) { mutableStateOf(original?.title.orEmpty()) }
    var category by remember(original?.id) { mutableStateOf(original?.category ?: "BIRTHDAY") }
    var rule by remember(original?.id) { mutableStateOf(original?.rule ?: DateRules.CIVIL) }
    var month by remember(original?.id) { mutableStateOf(original?.month ?: current.monthValue) }
    var day by remember(original?.id) { mutableStateOf(original?.day ?: current.dayOfMonth) }
    var offset by remember(original?.id) { mutableStateOf(original?.paschaOffset ?: 0) }
    var note by remember(original?.id) { mutableStateOf(original?.note.orEmpty()) }
    var showPresets by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val upcoming = runCatching { DateRules.nextOccurrence(rule, month, day, offset, current) }.getOrNull()

    Dialog(onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).fillMaxHeight(0.9f).imePadding(),
            shape = RoundedCornerShape(22.dp), tonalElevation = 6.dp
        ) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(if (original == null) "Add important date" else "Edit date",
                    style = MaterialTheme.typography.headlineSmall)
                OutlinedTextField(value = title, onValueChange = { title = it.take(120) },
                    label = { Text("Name *") }, placeholder = { Text("e.g. Mum's birthday") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Occasion type", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.forEach { option ->
                        FilterChip(selected = category == option,
                            onClick = { category = option },
                            label = { Text(option.lowercase().replaceFirstChar { it.uppercase() }) })
                    }
                }
                if (category == "SLAVA" || category == "HOLIDAY") {
                    Box {
                        OutlinedButton(onClick = { showPresets = true }) {
                            Text(if (category == "SLAVA") "Choose a Slava preset" else "Orthodox Easter preset")
                        }
                        DropdownMenu(expanded = showPresets,
                            onDismissRequest = { showPresets = false }) {
                            val options = if (category == "SLAVA") slavaPresets else
                                listOf(Preset("Orthodox Easter (Pascha)", DateRules.PASCHA, 1, 1))
                            options.forEach { preset ->
                                DropdownMenuItem(text = { Text(preset.name) }, onClick = {
                                    title = preset.name
                                    rule = preset.rule
                                    month = preset.month
                                    day = preset.day
                                    offset = preset.offset
                                    showPresets = false
                                })
                            }
                        }
                    }
                }
                OutlinedButton(onClick = {
                    val selected = upcoming ?: current
                    DatePickerDialog(context, { _, _, m, d ->
                        month = m + 1
                        day = d
                        rule = DateRules.CIVIL
                        offset = 0
                    }, selected.year, selected.monthValue - 1, selected.dayOfMonth).show()
                }) { Text("Choose custom date") }
                Text(when (rule) {
                    DateRules.JULIAN -> "Church calendar: $day/$month (Julian). Repeats yearly."
                    DateRules.PASCHA -> "Calculated every year from Orthodox Easter."
                    else -> "Annual date: $day/$month (civil calendar)."
                })
                if (upcoming != null) Text("Next: ${upcoming.format(dateFormat)}",
                    style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(value = note, onValueChange = { note = it.take(2000) },
                    label = { Text("Notes (optional)") },
                    modifier = Modifier.fillMaxWidth(), minLines = 2, maxLines = 4)
                Text("Reminders: 7 days before, 1 day before, and on the day (around 9 AM).",
                    style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically) {
                    if (original != null) TextButton(onClick = { confirmDelete = true }) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(enabled = title.trim().isNotEmpty() && upcoming != null,
                        onClick = { onSave(Draft(title.trim(), category, rule, month, day, offset, note)) }) {
                        Text("Save")
                    }
                }
            }
        }
    }
    if (confirmDelete && original != null) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Move to Trash?") },
        text = { Text("You can restore this date later from Safety → Trash.") },
        confirmButton = { TextButton(onClick = { onDelete(original) }) { Text("Move to Trash") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}
