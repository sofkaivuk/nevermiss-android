package com.nevermiss.app

import android.app.Activity
import android.app.Application
import android.net.Uri
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.util.UUID

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as NeverMissApplication
    private val dao = app.dao
    private val auth = if (app.firebaseReady) FirebaseAuth.getInstance() else null
    private var authListener: FirebaseAuth.AuthStateListener? = null

    val accountUid = MutableStateFlow(app.signedInUid())
    val accountEmail = MutableStateFlow(auth?.currentUser?.email)
    val cloudState: StateFlow<CloudState> = app.cloud.state
    val message = MutableStateFlow<String?>(null)
    val firebaseConfigured: Boolean get() = app.firebaseReady

    val occasions = accountUid.flatMapLatest { uid ->
        if (uid == null) dao.observeGuests() else dao.observeOwned(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val trash = accountUid.flatMapLatest { uid ->
        if (uid == null) dao.observeGuestTrash() else dao.observeOwnedTrash(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        if (auth != null) {
            val listener = FirebaseAuth.AuthStateListener { firebase ->
                val newUid = firebase.currentUser?.uid
                val changed = accountUid.value != newUid
                accountUid.value = newUid
                accountEmail.value = firebase.currentUser?.email
                if (changed || app.cloud.state.value.lastSynced == null) {
                    app.cloud.watchAccount(newUid)
                    viewModelScope.launch(Dispatchers.IO) {
                        if (newUid != null) dao.claimGuests(newUid)
                        app.queueCloudSync()
                        ReminderJobs.queueMaintenance(app)
                    }
                }
            }
            authListener = listener
            auth.addAuthStateListener(listener)
        } else {
            app.cloud.watchAccount(null)
        }
        app.queueCloudSync()
    }

    override fun onCleared() {
        authListener?.let { auth?.removeAuthStateListener(it) }
        super.onCleared()
    }

    fun save(
        original: Occasion?, title: String, category: String, rule: String,
        month: Int, day: Int, paschaOffset: Int, note: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                require(title.trim().isNotEmpty()) { "Please enter a name" }
                require(title.trim().length <= 120 && note.length <= 2000)
                DateRules.occurrence(2028, rule, month, day, paschaOffset)
                val uid = accountUid.value
                require(original == null || original.ownerUid == uid) { "Account changed; reopen this date" }
                val now = maxOf(System.currentTimeMillis(), (original?.updatedAt ?: 0) + 1)
                val entry = Occasion(
                    id = original?.id ?: UUID.randomUUID().toString(), ownerUid = uid,
                    title = title.trim(), category = category, rule = rule,
                    month = month, day = day, paschaOffset = paschaOffset,
                    note = note.trim(), updatedAt = now, dirty = true
                )
                dao.upsert(entry)
                app.cloud.markLocalPending()
                app.queueCloudSync()
                ReminderJobs.queueMaintenance(app)
                message.value = "Date saved on this phone"
            } catch (e: Exception) {
                message.value = e.message ?: "Unable to save date"
            }
        }
    }

    fun trashEvent(event: Occasion) = changeDeleted(event, true)
    fun restoreEvent(event: Occasion) = changeDeleted(event, false)

    private fun changeDeleted(event: Occasion, delete: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            if (event.ownerUid != accountUid.value) return@launch
            dao.upsert(event.copy(
                deletedAt = if (delete) System.currentTimeMillis() else null,
                updatedAt = maxOf(System.currentTimeMillis(), event.updatedAt + 1),
                dirty = true
            ))
            app.cloud.markLocalPending()
            app.queueCloudSync()
            ReminderJobs.queueMaintenance(app)
            message.value = if (delete) "Moved to Trash" else "Restored"
        }
    }

    fun signIn(activity: Activity) {
        val firebaseAuth = auth ?: run {
            message.value = "Firebase is not configured. See SETUP.md."
            return
        }
        viewModelScope.launch {
            try {
                val resourceId = app.resources.getIdentifier(
                    "default_web_client_id", "string", app.packageName
                )
                require(resourceId != 0) { "Missing Google OAuth client ID in Firebase configuration" }
                val clientId = app.getString(resourceId)
                val option = GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(clientId)
                    .setAutoSelectEnabled(false)
                    .build()
                val response = CredentialManager.create(activity).getCredential(
                    context = activity,
                    request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                )
                val credential = response.credential
                require(credential is CustomCredential &&
                    credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    "Unexpected Google credential"
                }
                val googleToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                firebaseAuth.signInWithCredential(
                    GoogleAuthProvider.getCredential(googleToken, null)
                ).await()
                message.value = "Google account connected; downloading your dates"
            } catch (e: Exception) {
                message.value = "Sign-in not completed: ${e.localizedMessage ?: "try again"}"
            }
        }
    }

    fun signOut(activity: Activity) {
        auth?.signOut()
        viewModelScope.launch {
            try { CredentialManager.create(activity)
                .clearCredentialState(ClearCredentialStateRequest()) }
            catch (_: Exception) { /* Firebase sign-out already completed */ }
        }
        message.value = "Signed out. Local dates for this account are hidden."
    }

    fun retrySync() { app.queueCloudSync() }

    fun exportTo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val entries = accountUid.value?.let { dao.ownedEntries(it) } ?: dao.guestEntries()
                val data = BackupCodec.encode(entries)
                app.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(data.toByteArray(Charsets.UTF_8))
                } ?: error("Could not write the file")
                message.value = "Backup exported (${entries.count { it.deletedAt == null }} dates)"
            } catch (e: Exception) { message.value = "Export failed: ${e.localizedMessage}" }
        }
    }

    fun importFrom(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val text = app.contentResolver.openInputStream(uri)?.use { input ->
                    val bytes = input.readNBytes(5_000_001)
                    require(bytes.size <= 5_000_000) { "File too large" }
                    bytes.toString(Charsets.UTF_8)
                } ?: error("Could not open the file")
                // Parse and validate whole backup before making any database changes.
                val imported = BackupCodec.decode(text)
                val uid = accountUid.value
                var added = 0
                imported.forEachIndexed { index, event ->
                    // Do not overwrite entries already present (including deleted ones).
                    val already = dao.getById(event.id)
                    if (already == null || already.ownerUid != uid) {
                        // A different signed-in account must not lose data to an ID collision.
                        val safeId = if (already != null) UUID.randomUUID().toString() else event.id
                        dao.upsert(event.copy(id = safeId, ownerUid = uid,
                            updatedAt = System.currentTimeMillis() + index, dirty = true))
                        added++
                    }
                }
                if (added > 0) app.cloud.markLocalPending()
                app.queueCloudSync()
                ReminderJobs.queueMaintenance(app)
                message.value = "Imported $added new dates; existing dates kept"
            } catch (e: Exception) { message.value = "Import failed: ${e.localizedMessage}" }
        }
    }

    fun report(text: String) { message.value = text }
    fun clearMessage() { message.value = null }
}
