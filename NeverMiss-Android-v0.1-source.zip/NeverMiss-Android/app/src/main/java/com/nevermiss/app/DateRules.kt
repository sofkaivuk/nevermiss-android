package com.nevermiss.app

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Calendar arithmetic, independent of Android and Firebase. */
object DateRules {
    const val CIVIL = "CIVIL"
    const val JULIAN = "JULIAN"
    const val PASCHA = "PASCHA"
    val supportedReminders = listOf(7, 1, 0)

    // Converts a date in the proleptic Julian calendar to Gregorian, using Julian Day Numbers.
    // No hard-coded 13-day shift: remains correct after the year 2100.
    fun fromJulian(year: Int, month: Int, day: Int): LocalDate {
        require(year in 1..9998 && month in 1..12)
        val maxDay = when (month) {
            2 -> if (year % 4 == 0) 29 else 28
            4, 6, 9, 11 -> 30
            else -> 31
        }
        require(day in 1..maxDay) { "Invalid Julian date" }
        val a = (14 - month) / 12
        val y = year + 4800 - a
        val m = month + 12 * a - 3
        val jdn = day + (153 * m + 2) / 5 + 365L * y + y / 4 - 32083
        return LocalDate.ofEpochDay(jdn - 2440588L)
    }

    /** Julian Paschalion used for Serbian Orthodox Easter, returned as a civil date. */
    fun orthodoxEaster(year: Int): LocalDate {
        val a = year % 4
        val b = year % 7
        val c = year % 19
        val d = (19 * c + 15) % 30
        val e = (2 * a + 4 * b - d + 34) % 7
        val month = (d + e + 114) / 31
        val day = (d + e + 114) % 31 + 1
        return fromJulian(year, month, day)
    }

    fun occurrence(
        year: Int,
        rule: String,
        month: Int,
        day: Int,
        paschaOffset: Int = 0
    ): LocalDate = when (rule) {
        CIVIL -> {
            // Leap-day birthdays default to February 28 in non-leap years in this alpha.
            if (month == 2 && day == 29 && !LocalDate.of(year, 1, 1).isLeapYear) {
                LocalDate.of(year, 2, 28)
            } else LocalDate.of(year, month, day)
        }
        JULIAN -> if (month == 2 && day == 29 && year % 4 != 0) {
            fromJulian(year, 2, 28)
        } else fromJulian(year, month, day)
        PASCHA -> orthodoxEaster(year).plusDays(paschaOffset.toLong())
        else -> error("Unknown recurrence rule: $rule")
    }

    fun nextOccurrence(
        rule: String,
        month: Int,
        day: Int,
        paschaOffset: Int,
        from: LocalDate
    ): LocalDate = ((from.year - 1)..(from.year + 8))
        .asSequence()
        .map { occurrence(it, rule, month, day, paschaOffset) }
        .filter { !it.isBefore(from) }
        .minOrNull() ?: error("No upcoming occurrence")

    fun dueToday(rule: String, month: Int, day: Int, paschaOffset: Int,
                 daysBefore: Int, today: LocalDate): Boolean {
        val nextDate = nextOccurrence(rule, month, day, paschaOffset, today)
        return nextDate.minusDays(daysBefore.toLong()) == today
    }

    /** One reminder check at 9am in the phone's current time zone. */
    fun nextAlarm(now: ZonedDateTime, hour: Int = 9): ZonedDateTime {
        val today = now.toLocalDate().atTime(hour, 0).atZone(now.zone)
        return if (today.isAfter(now)) today else today.plusDays(1)
    }
}
