package com.nevermiss.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime

class DateRulesTest {
    @Test fun `Saint Nicholas stays on December 19 in 2026`() {
        assertEquals(LocalDate.of(2026, 12, 19), DateRules.fromJulian(2026, 12, 6))
    }

    @Test fun `Julian offset changes after 2100`() {
        assertEquals(LocalDate.of(2100, 12, 20), DateRules.fromJulian(2100, 12, 6))
    }

    @Test fun `Orthodox Easter dates are correctly computed`() {
        assertEquals(LocalDate.of(2026, 4, 12), DateRules.orthodoxEaster(2026))
        assertEquals(LocalDate.of(2027, 5, 2), DateRules.orthodoxEaster(2027))
    }

    @Test fun `Leap day uses February 28 in non leap years`() {
        assertEquals(LocalDate.of(2027, 2, 28),
            DateRules.occurrence(2027, DateRules.CIVIL, 2, 29))
        assertEquals(LocalDate.of(2028, 2, 29),
            DateRules.occurrence(2028, DateRules.CIVIL, 2, 29))
    }

    @Test fun `December reminder works for January occasion`() {
        assertTrue(DateRules.dueToday(DateRules.CIVIL, 1, 1, 0, 7,
            LocalDate.of(2026, 12, 25)))
        assertFalse(DateRules.dueToday(DateRules.CIVIL, 1, 1, 0, 7,
            LocalDate.of(2026, 12, 26)))
    }

    @Test fun `Next reminder alarm is always future`() {
        val zone = ZoneId.of("Europe/Belgrade")
        assertEquals(LocalDate.of(2026, 12, 20),
            DateRules.nextAlarm(ZonedDateTime.of(2026, 12, 19, 10, 0, 0, 0, zone))
                .toLocalDate())
    }
}
